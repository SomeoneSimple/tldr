# convert

> This command is an alias of `magick convert`.
> Note: this alias is deprecated since ImageMagick 7. It has been replaced by `magick`.
> Use `magick convert` if you need to use the old tool in versions 7+.

- View documentation for the original command:

`tldr magick convert`
