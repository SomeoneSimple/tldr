# ClamAV

> Open-source anti-virus program.
> ClamAV isn't a command, but a set of commands.
> More information: <https://www.clamav.net>.

- View documentation for scanning files using the `clamd` daemon:

`tldr clamdscan`

- View documentation for scanning files without the `clamd` daemon running:

`tldr clamscan`

- View documentation for updating the virus definitions:

`tldr freshclam`
