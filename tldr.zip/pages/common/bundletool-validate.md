# bundletool validate

> Manipulate Android Application Bundles.
> More information: <https://developer.android.com/tools/bundletool>.

- Verify a bundle and display detailed information about it:

`bundletool validate --bundle {{path/to/bundle.aab}}`
