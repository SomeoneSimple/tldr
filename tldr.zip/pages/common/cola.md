# cola

> This command is an alias of `git-cola`.

- View documentation for the original command:

`tldr git-cola`
